-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: daiyunjie_cn
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `typecho_comments`
--

DROP TABLE IF EXISTS `typecho_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_comments` (
  `coid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned DEFAULT '0',
  `created` int(10) unsigned DEFAULT '0',
  `author` varchar(150) DEFAULT NULL,
  `authorId` int(10) unsigned DEFAULT '0',
  `ownerId` int(10) unsigned DEFAULT '0',
  `mail` varchar(150) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `agent` varchar(511) DEFAULT NULL,
  `text` text,
  `type` varchar(16) DEFAULT 'comment',
  `status` varchar(16) DEFAULT 'approved',
  `parent` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`coid`),
  KEY `cid` (`cid`),
  KEY `created` (`created`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_comments`
--

LOCK TABLES `typecho_comments` WRITE;
/*!40000 ALTER TABLE `typecho_comments` DISABLE KEYS */;
INSERT INTO `typecho_comments` VALUES (2,5,1692082947,'Adlerian',1,1,'daiyunjie@adlerian.xyz','https://blog.adlerian.xyz/','117.129.89.87','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.203','xixx','comment','approved',0);
/*!40000 ALTER TABLE `typecho_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_contents`
--

DROP TABLE IF EXISTS `typecho_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_contents` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `created` int(10) unsigned DEFAULT '0',
  `modified` int(10) unsigned DEFAULT '0',
  `text` longtext,
  `order` int(10) unsigned DEFAULT '0',
  `authorId` int(10) unsigned DEFAULT '0',
  `template` varchar(32) DEFAULT NULL,
  `type` varchar(16) DEFAULT 'post',
  `status` varchar(16) DEFAULT 'publish',
  `password` varchar(32) DEFAULT NULL,
  `commentsNum` int(10) unsigned DEFAULT '0',
  `allowComment` char(1) DEFAULT '0',
  `allowPing` char(1) DEFAULT '0',
  `allowFeed` char(1) DEFAULT '0',
  `parent` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`cid`),
  UNIQUE KEY `slug` (`slug`),
  KEY `created` (`created`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_contents`
--

LOCK TABLES `typecho_contents` WRITE;
/*!40000 ALTER TABLE `typecho_contents` DISABLE KEYS */;
INSERT INTO `typecho_contents` VALUES (2,'关于','start-page',1691718180,1691994158,'<!--markdown-->本站是Moose Cat（驼鹿猫）的官方博客网站，文章版权归Moose Cat（驼鹿猫)所有！',1,1,NULL,'page','publish',NULL,0,'1','1','1',0),(4,'【PDF.js】PDF.js的简单使用与CDN加速遇到的问题','4',1692008940,1692069859,'<!--markdown-->[toc]\r\n\r\n##  一、PDF.js是什么？\r\n\r\n>`PDF.JS`是一个用于在Web浏览器中显示PDF文件的`JavaScript`库。它不需要依赖任何插件或外部程序，可以直接在浏览器中渲染和显示PDF文件。PDF.JS提供了一组`JavaScript API`，开发者可以使用这些API来进行自定义开发，如显示、搜索和打印PDF文件等。通过使用PDF.JS，开发者可以在Web应用程序中无缝地集成PDF文件的显示和操作功能。\r\n\r\n##  二、PDF.js\r\n\r\n[PDF.js文档](https://mozilla.github.io/pdf.js/)\r\n\r\n[PDF.JS  GitHub仓库](https://github.com/mozilla/pdf.js)\r\n\r\n##  三、 选择PDF.js的版本下载\r\n\r\n### 1. Prebuilt (现代浏览器)    *作者选择\r\n\r\n>包括PDFjs和查看器的通用构建\r\n\r\n<a href=\"https://github.com/mozilla/pdf.js/releases/download/v3.9.179/pdfjs-3.9.179-dist.zip\"><button>预建（V3.9.179）</button></a>\r\n\r\n### 2. Prebuilt (历史淘汰浏览器)\r\n\r\n>包括PDFjs和查看器的通用构建\r\n\r\n<a href=\"https://github.com/mozilla/pdf.js/releases/download/v3.9.179/pdfjs-3.9.179-legacy-dist.zip\"><button>预建（V3.9.179）</button></a>\r\n\r\n### 3. Source 来源\r\n\r\n>要获取当前代码的本地副本，请使用git进行克隆:\r\n\r\n```shell\r\n$ git clone https://github.com/mozilla/pdf.js.git\r\n$ cd pdf.js\r\n```\r\n\r\n###  4. 通过CDN加速\r\n\r\n>以下是托管网站，也可以把环境自己cdn\r\n\r\n- https://www.jsdelivr.com/package/npm/pdfjs-dist\r\n- https://cdnjs.com/libraries/pdf.js\r\n- https://unpkg.com/pdfjs-dist/\r\n\r\n###  5. 文件树\r\n\r\n####  Prebuilt \r\n\r\n```md\r\n├── build/\r\n│   ├── pdf.js                             - display layer\r\n│   ├── pdf.js.map                         - display layer\'s source map\r\n│   ├── pdf.worker.js                      - core layer\r\n│   └── pdf.worker.js.map                  - core layer\'s source map\r\n├── web/\r\n│   ├── cmaps/                             - character maps (required by core)\r\n│   ├── compressed.tracemonkey-pldi-09.pdf - PDF file for testing purposes\r\n│   ├── debugger.js                        - helpful debugging features\r\n│   ├── images/                            - images for the viewer and annotation icons\r\n│   ├── locale/                            - translation files\r\n│   ├── viewer.css                         - viewer style sheet\r\n│   ├── viewer.html                        - viewer layout\r\n│   ├── viewer.js                          - viewer layer\r\n│   └── viewer.js.map                      - viewer layer\'s source map\r\n└── LICENSE\r\n```\r\n\r\n\r\n\r\n####  Source\r\n\r\n```md\r\n├── docs/                                  - website source code\r\n├── examples/                              - simple usage examples\r\n├── extensions/                            - browser extension source code\r\n├── external/                              - third party code\r\n├── l10n/                                  - translation files\r\n├── src/\r\n│   ├── core/                              - core layer\r\n│   ├── display/                           - display layer\r\n│   ├── shared/                            - shared code between the core and display layers\r\n│   ├── interfaces.js                      - interface definitions for the core/display layers\r\n│   └── pdf.*.js                           - wrapper files for bundling\r\n├── test/                                  - unit, font, reference, and integration tests\r\n├── web/                                   - viewer layer\r\n├── LICENSE\r\n├── README.md\r\n├── gulpfile.js                            - build scripts/logic\r\n├── package-lock.json                      - pinned dependency versions\r\n└── package.json                           - package definition and dependencies\r\n```\r\n\r\n### 6. 尝试查看器\r\n\r\n对于预建版本或源版本，在浏览器中打开 `web/viewer.html` 并加载测试 PDF。注意:worker 没有为 file://urls 启用，所以使用服务器。如果你正在使用源代码构建并拥有节点，那么你可以运行 `gulp server`。\r\n\r\n##  四、选择文档（不是使用默认文件名）\r\n\r\n构建的代码示例一般都放了一个文档`compressed.tracemonkey-pldi-09.pdf`\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/45090773edddbb257f65c.png\"></div>\r\n\r\n\r\n你如果想用很简单的方法就把你要使用的文档改成这个名字\r\n\r\n如果你是api、或者渲染就改成相关的名称\r\n\r\n##  五、网页标题不显示文件的名称\r\n\r\n找到viewer.js文档下面的691行\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/45090773edddbb257f65c.png\"></div>\r\n\r\n\r\n##  六、视图\r\n\r\n每个PDE页面都有自己的视口，它定义了像素大小(72DP 1)和初始转。默认情况下，视口缩放为PDE的原始大小，但可以通过修改视口来更改。当视口被创建时，一个初始\r\n变换矩阵也将被创建，它考虑到所需的缩放，旋转，并转换坐标系(PDF文档中的0.0点位于左下角，而画布0,0位于左上角)。\r\n\r\n```javascript\r\nvar scale = 1.5;\r\nvar viewport = page.getViewport({ scale: scale, });\r\n// Support HiDPI-screens.\r\nvar outputScale = window.devicePixelRatio || 1;\r\n\r\nvar canvas = document.getElementById(\'the-canvas\');\r\nvar context = canvas.getContext(\'2d\');\r\n\r\ncanvas.width = Math.floor(viewport.width * outputScale);\r\ncanvas.height = Math.floor(viewport.height * outputScale);\r\ncanvas.style.width = Math.floor(viewport.width) + \"px\";\r\ncanvas.style.height =  Math.floor(viewport.height) + \"px\";\r\n\r\nvar transform = outputScale !== 1\r\n  ? [outputScale, 0, 0, outputScale, 0, 0]\r\n  : null;\r\n\r\nvar renderContext = {\r\n  canvasContext: context,\r\n  transform: transform,\r\n  viewport: viewport\r\n};\r\npage.render(renderContext);\r\n```\r\n\r\n或者，如果希望画布渲染到某个像素大小，可以执行以下操作。\r\n\r\n```javascript\r\nvar desiredWidth = 100;\r\nvar viewport = page.getViewport({ scale: 1, });\r\nvar scale = desiredWidth / viewport.width;\r\nvar scaledViewport = page.getViewport({ scale: scale, });\r\n```\r\n\r\n##  六、加速pdf打开加载速度\r\n\r\n1.优化你的pdf文件。如果你有权限编辑pdf文件，可以尝试将文件进行压缩或优化，这样可以减小文件的大小，从而提高打开速度。\r\n2.用更快的网络连接。如果你是通过网络打开pdf文件，尝试使用更快的网络连接，如使用有线网络代替无线网络，或者使用更快的互联网服务提供商。\r\n3.添加服务器的带宽\r\n4.把build文件夹和web中的viewer.js使用阿里云cdn进行加速。\r\n\r\n##  七、阿里云CDN加速所遇到的问题\r\n\r\n> 在我使用的时候造成了文档打开白屏只显示边框，不显示文章。导致这种原因是因为cdn加速的头部没有设置\r\n\r\n1. 打开cdn控制台   [CDN云产品](https://www.aliyun.com/product/cdn?userCode=8xgvozil)\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/f0bcc6c671b239076672d.png\"></div>\r\n\r\n\r\n2. 开通CDN\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/cfed94cc64e4841fb7b4a.png\"></div>\r\n\r\n\r\n\r\n3. 开通进入控制台\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/43471eb40134050cd8434.png\"></div>\r\n\r\n\r\n4. 添加域名\r\n\r\n5. 选择加速区域\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/bee753fdd8be834e1e841.png\"></div>\r\n\r\n\r\n\r\n6. DNS解析验证\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/c507119a6b029fe5666a6.png\"></div>\r\n\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/69b1db6778a313f7a8bca.png\"></div>\r\n\r\n7. 选择业务类型\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/d92ce44675d0c0bbb527a.png\"></div>\r\n\r\n\r\n8. 添加源站信息\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/647ac059c6269a3668272.png\"></div>\r\n\r\n\r\n9. 默认配置\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/5a51016f9f702464bc3af.png\"></div>\r\n\r\n\r\n10. 配置CNAME\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/6bdfc1edaeefb5fa3d389.png\"></div>\r\n\r\n\r\n11. 选择预热\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/0dddc81d5f8e5f94267ca.png\"></div>\r\n\r\n\r\n12. 访问域名\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/742ca809d01d368a3057d.png\"></div>\r\n\r\n\r\n    全部速度有大的提升\r\n    \r\n<div><img src=\"https://image.adlerian.xyz/file/499aa8ad9a0013e1d2dd8.png\"></div>\r\n\r\n\r\n13. 注意事项：\r\n\r\n    1. 购买资源包会省钱 地址：[CDN资源包](https://t.aliyun.com/U/POyj18)\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/b17d0c2744b5aa6fdf4d8.png\"></div>\r\n\r\n\r\n    2. 添加标头，不然会爆跨域错误\r\n    \r\n<div><img src=\"https://image.adlerian.xyz/file/35fc8fbca3604878ea9a0.png\"></div>\r\n\r\n\r\n<hr>\r\n\r\n\r\n<div><img src=\"https://image.adlerian.xyz/file/83ecec513aa10db8a9c8f.png\"></div>\r\n\r\n<div align=\"center\"><a rel=\"license\" href=\"http://creativecommons.org/licenses/by-nc-sa/4.0/\" target=\"_blank\"><img alt=\"知识共享许可协议\" style=\"border-width:0\" src=\"https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png\"/></a></div>\r\n\r\n',0,1,NULL,'post','publish',NULL,0,'1','1','1',0),(5,'【Node.js】node.js使用中的所遇到的问题','5',1692065160,1692080699,'<!--markdown-->##  一、npm下载pnpm、yarn后无法使用\r\n\r\n###  下载报错\r\n\r\n![img20230804150749](https://blog.adlerian.xyz/usr/uploads/2023/08/1137321672.png)\r\n\r\n###  打开管理身份结束脚本\r\n\r\n> 1、win+s 在系统中搜索框 输入“Windos PowerShell\"右击“管理员身份运行”or 使用 PowerShell邮件管理员身份打开\r\n>\r\n> 2、输入”set-ExecutionPolicy RemoteSigned”回车根据提示输入A\r\n\r\n![img20230804150834](https://blog.adlerian.xyz/usr/uploads/2023/08/2197106293.png)\r\n\r\n###  发现还是失败\r\n\r\n> 出现了已经存在pnpm\r\n\r\n打开依赖地址》AppData>Roaming》npm  删除关于pnpm相关的信息\r\n\r\n![img20230804151520](https://blog.adlerian.xyz/usr/uploads/2023/08/4130287851.png)\r\n\r\n###  运行，成功\r\n\r\n![image-20230809180055763](https://blog.adlerian.xyz/usr/uploads/2023/08/2073660862.png)\r\n',0,1,NULL,'post','publish',NULL,1,'1','1','1',0),(6,'img20230804150749-1691575044290-5.png','img20230804150749-1691575044290-5-png',1692064995,1692064995,'a:5:{s:4:\"name\";s:37:\"img20230804150749-1691575044290-5.png\";s:4:\"path\";s:35:\"/usr/uploads/2023/08/1137321672.png\";s:4:\"size\";i:78895;s:4:\"type\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";}',1,1,NULL,'attachment','publish',NULL,0,'1','0','1',5),(7,'img20230804150834.png','img20230804150834-png',1692065044,1692065044,'a:5:{s:4:\"name\";s:21:\"img20230804150834.png\";s:4:\"path\";s:35:\"/usr/uploads/2023/08/2197106293.png\";s:4:\"size\";i:11192;s:4:\"type\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";}',2,1,NULL,'attachment','publish',NULL,0,'1','0','1',5),(8,'img20230804151520.png','img20230804151520-png',1692065102,1692065102,'a:5:{s:4:\"name\";s:21:\"img20230804151520.png\";s:4:\"path\";s:35:\"/usr/uploads/2023/08/4130287851.png\";s:4:\"size\";i:46212;s:4:\"type\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";}',3,1,NULL,'attachment','publish',NULL,0,'1','0','1',5),(9,'image-20230809180055763.png','image-20230809180055763-png',1692065123,1692065123,'a:5:{s:4:\"name\";s:27:\"image-20230809180055763.png\";s:4:\"path\";s:35:\"/usr/uploads/2023/08/2073660862.png\";s:4:\"size\";i:21785;s:4:\"type\";s:3:\"png\";s:4:\"mime\";s:9:\"image/png\";}',4,1,NULL,'attachment','publish',NULL,0,'1','0','1',5),(11,'友情链接','11',1692071580,1692071721,'<!--markdown--># 本页面仅作为演示使用\r\n\r\n友链页面请转至 https://www.onesrc.cn/links.html\r\n\r\n## 友情链接:\r\n\r\n<ul class=\"flinks\">\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n\r\n<li>Baidu</li>\r\n<li>https://www.baidu.com/</li>\r\n<li>https://www.baidu.com/favicon.ico</li>\r\n<li>baidu.com</li>\r\n\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n</ul>\r\n\r\n## 其他内容\r\n\r\n又有一些链接\r\n\r\n<ul class=\"flinks\">\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n\r\n<li>Baidu</li>\r\n<li>https://www.baidu.com/</li>\r\n<li>https://www.baidu.com/favicon.ico</li>\r\n<li>baidu.com</li>\r\n\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n\r\n<li>一元-ONESRC</li>\r\n<li>https://www.onesrc.cn/</li>\r\n<li>https://cdn.onesrc.cn/uploads/images/favicon.png</li>\r\n<li>onesrc.cn</li>\r\n</ul>\r\n\r\n## 结尾内容\r\n\r\n这是文章结尾。\r\n\r\n!!!\r\n<script>document.querySelectorAll(\'ul.flinks\').forEach(function(e){let a=e;if(a){let ns=a.querySelectorAll(\"li\");let str=\'<div style=\"display:inline-block;\">\';let bgid=0;const bgs=[\"bg-white\",\"bg-grey\",\"bg-deepgrey\",\"bg-blue\",\"bg-purple\",\"bg-green\",\"bg-yellow\",\"bg-red\",\"bg-orange\"];for(let i=0;i<ns.length;i+=4){str+=(`<div class=\"flink-item ${bgs[Math.floor(Math.random() * 9)]}\"><div class=\"flink-title\"><a href=\"${ns[i+1].innerText}\"target=\"_blank\"rel=\"external nofollow ugc\">${ns[i].innerText}</a></div><div class=\"flink-link\"><div class=\"flink-link-ico\"style=\"background: url(${ns[i+2].innerText});background-size: 42px auto;\"></div><div class=\"flink-link-text\">${ns[i+3].innerText}</div></div></div>`)}str+=`</div>`;let n1=document.createElement(\"div\");n1.innerHTML=str;a.parentNode.insertBefore(n1,a);a.style=\"display: none;\"}else{console.log(\'No such id \"flinks\"\')}});</script>\r\n<style>.flink-item{width:300px;height:100px;position:relative;margin:10px;background-color:#fff;border-radius:3px;float:left}.flink-title{left:25px;top:25px;position:absolute}.flink-title a{font-size:17px;color:#f1f1f1;line-height:17px;word-break:break-all;text-decoration:none;outline:0}.flink-link{right:0;bottom:0;padding:0 15px 15px;position:absolute;text-align:center}.flink-link-text{font-size:12px;color:#f1f1f1}.flink-link-ico{display:inline-block;width:42px;height:42px;border-radius:50%}.bg-white{background-color:#fff!important}.bg-grey{background-color:#f7f7f7!important}.bg-deepgrey{background-color:rgba(0,0,0,.5)!important}.bg-blue{background-color:#6fa3ef!important}.bg-purple{background-color:#bc99c4!important}.bg-green{background-color:#46c47c!important}.bg-yellow{background-color:#f9bb3c!important}.bg-red{background-color:#e8583d!important}.bg-orange{background-color:#f68e5f!important}</style>\r\n!!!',2,1,NULL,'page','hidden',NULL,0,'1','1','1',0),(13,'【Vue3】Vue3+Vite+TS使用npm包引入百度地图','13',0,1692088223,'<!--markdown-->\r\n##  Vue3+Vite+TS引入百度地图\r\n###  一、注册\r\n\r\n\r\n官网:point_right:[百度地图开放平台](https://lbsyun.baidu.com/index.php)\r\n\r\n注册好的登录打开控制台\r\n\r\n<div><img src=\"https://img-blog.csdnimg.cn/65197e6ee3624eaf9347163f62656982.png\" ></div>\r\n\r\n\r\n打开`应用管理`下的二级菜单`我的应用`，选择`创建应用`\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/a1892f11d17d4bb883f125f386e690b7.png#pic_center)\r\n\r\n\r\n填写名称选择自己要使用的\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/0079bc2f234d4696afcebbb73632f674.png#pic_center)\r\n\r\n\r\n复制AK-》到后面可以直接放到ak上面\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/aba52ed2b2294f7e93550a9de6ecb751.png#pic_center)\r\n\r\n\r\n### 二、安装依赖包\r\n\r\n```bash\r\n// vue3\r\n$ npm install vue-baidu-map-3x --save\r\n// 或者\r\n$ yarn add baidu-map-vue3\r\n\r\n// vue2\r\n$ npm install vue2-baidu-map --save\r\n```\r\n\r\n###  三、参考文档\r\n\r\n[百度地图JavaScript开发文档](https://lbsyun.baidu.com/index.php?title=jspopularGL)\r\n\r\n[百度地图3方npm包](https://map.heifahaizei.com/doc/index.html)\r\n\r\n[百度地图VUE3组件库 (lunnlew.github.io)](https://lunnlew.github.io/baidu-map/#/)\r\n\r\n###  四、全局注册\r\n\r\n```typescript\r\nimport BaiduMap from \'vue-baidu-map-3x\'\r\n\r\nconst app = createApp(App);\r\napp.use(BaiduMap, {\r\n  // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */\r\n  ak: \'百度地图ak\',\r\n  // v:\'2.0\',  // 默认使用3.0\r\n  // type: \'WebGL\' // ||API 默认API  (使用此模式 BMap=BMapGL)\r\n});\r\n```\r\n\r\n```html\r\n<template>\r\n  <baidu-map class=\"bm-view\" center=\"汕头\" :zoom=\"15\" :scroll-wheel-zoom=\"true\">\r\n    <bm-scale anchor=\"BMAP_ANCHOR_TOP_RIGHT\"></bm-scale>\r\n    <bm-geolocation\r\n      anchor=\"BMAP_ANCHOR_BOTTOM_RIGHT\"\r\n      :showAddressBar=\"true\"\r\n      :autoLocation=\"true\"\r\n    ></bm-geolocation>\r\n    <bm-city-list anchor=\"BMAP_ANCHOR_TOP_LEFT\"></bm-city-list>\r\n  </baidu-map>\r\n</template>\r\n\r\n<script setup lang=\"ts\">\r\nimport { ref } from \"vue\";\r\n\r\nconst mapStyle = ref({\r\n  styleJson: [\r\n    {\r\n      featureType: \"all\",\r\n      elementType: \"geometry\",\r\n      stylers: {\r\n        hue: \"#007fff\",\r\n        saturation: 89,\r\n      },\r\n    },\r\n    {\r\n      featureType: \"water\",\r\n      elementType: \"all\",\r\n      stylers: {\r\n        color: \"#ffffff\",\r\n      },\r\n    },\r\n  ],\r\n});\r\n</script>\r\n<style scoped>\r\n.bm-view {\r\n  width: 100%;\r\n  height: 80%;\r\n}\r\n</style>\r\n\r\n```\r\n\r\n###  五、局部导入\r\n\r\n```html\r\n<template>\r\n    <baidu-map\r\n        class=\"map\"\r\n        ref=\"map\"\r\n        :apiKey=\"apiKey\"\r\n        :center=\"point\"\r\n        >\r\n    </baidu-map>\r\n</template>\r\n\r\n<script setup lang=\"ts\">\r\nimport { BaiduMap } from \'baidu-map-vue3\'\r\nconst point = ref({\r\n    lng: 116.403963,\r\n    lat: 39.915119,\r\n})\r\n</script>\r\n<style lang=\"less\">\r\n.map {\r\n    width: 100%;\r\n    height: 400px;\r\n}\r\n</style>\r\n```\r\n\r\n###   六、断网地图的使用\r\n\r\n```typescript\r\nimport BaiduMapOffline from \'vue-baidu-map-offline\';\r\nimport BaiduMap from \'vue-baidu-map-3x\'\r\n\r\napp.use(BaiduMapOffline, {\r\n    offline: true\r\n});\r\napp.use(BaiduMap, {\r\n    ak: \'百度地图ak\',\r\n    v: \'3.0\',\r\n    // type: \'WebGL\'\r\n});\r\n```\r\n\r\n###  八、项目使用成功图片\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/e4c4b6f9652048d88ed4239153e654b6.png#pic_center)\r\n\r\n\r\n###  九、使用卫星图\r\n\r\n```html\r\n<template>\r\n  <baidu-map class=\"map\" :center=\"{ lng: 116.404, lat: 39.915 }\" :zoom=\"15\" mapType=\"BMAP_SATELLITE_MAP\">\r\n  </baidu-map>\r\n</template>\r\n```\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/1c8ef6383afb4759a48915a6f0d88a1e.png#pic_center)\r\n\r\n\r\n##  Vue3+Vite+TS引入高德地图\r\n\r\n```bash\r\nnpm i @amap/amap-jsapi-loader --save\r\n```\r\n\r\n\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/ea4eb1256ea54357bc1b06d20fadbdb3.png#pic_center)\r\n\r\n\r\n\r\n\r\n![在这里插入图片描述](https://img-blog.csdnimg.cn/8fbf8b162e1942b799aa4b5642a87606.png#pic_center)\r\n\r\n\r\n##  npm包查找地图依赖包\r\n\r\n[npm包官网](https://www.npmjs.com/)\r\n\r\n',0,1,NULL,'post_draft','publish',NULL,0,'1','1','1',0);
/*!40000 ALTER TABLE `typecho_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_fields`
--

DROP TABLE IF EXISTS `typecho_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_fields` (
  `cid` int(10) unsigned NOT NULL,
  `name` varchar(150) NOT NULL,
  `type` varchar(8) DEFAULT 'str',
  `str_value` text,
  `int_value` int(10) DEFAULT '0',
  `float_value` float DEFAULT '0',
  PRIMARY KEY (`cid`,`name`),
  KEY `int_value` (`int_value`),
  KEY `float_value` (`float_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_fields`
--

LOCK TABLES `typecho_fields` WRITE;
/*!40000 ALTER TABLE `typecho_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `typecho_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_metas`
--

DROP TABLE IF EXISTS `typecho_metas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_metas` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `type` varchar(32) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `count` int(10) unsigned DEFAULT '0',
  `order` int(10) unsigned DEFAULT '0',
  `parent` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`mid`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_metas`
--

LOCK TABLES `typecho_metas` WRITE;
/*!40000 ALTER TABLE `typecho_metas` DISABLE KEYS */;
INSERT INTO `typecho_metas` VALUES (2,'前端开发','H5_JS','category','',1,1,0),(3,'JS插件与框架','H5_kj','category','',1,1,2),(4,'PDF.js','PDF-js','tag',NULL,1,0,0),(5,'前端','前端','tag',NULL,1,0,0),(6,'预览','预览','tag',NULL,1,0,0),(7,'小技能','小技能','tag',NULL,1,0,0),(8,'后端开发','web_HD','category','',1,2,0),(9,'node.js','node_js','category','Node.js 是一个开源的、跨平台的 JavaScript 运行时环境。',1,1,8),(10,'node','node','tag',NULL,1,0,0),(11,'javascript','javascript','tag',NULL,1,0,0),(12,'web','web','tag',NULL,1,0,0);
/*!40000 ALTER TABLE `typecho_metas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_options`
--

DROP TABLE IF EXISTS `typecho_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_options` (
  `name` varchar(32) NOT NULL,
  `user` int(10) unsigned NOT NULL DEFAULT '0',
  `value` text,
  PRIMARY KEY (`name`,`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_options`
--

LOCK TABLES `typecho_options` WRITE;
/*!40000 ALTER TABLE `typecho_options` DISABLE KEYS */;
INSERT INTO `typecho_options` VALUES ('actionTable',0,'a:0:{}'),('allowRegister',0,'0'),('allowXmlRpc',0,'1'),('attachmentTypes',0,'@image@,@doc@,md'),('autoSave',0,'0'),('autoSave',1,'1'),('charset',0,'UTF-8'),('commentDateFormat',0,'F jS, Y \\a\\t h:i a'),('commentsAntiSpam',0,'1'),('commentsAutoClose',0,'0'),('commentsAvatar',0,'1'),('commentsAvatarRating',0,'X'),('commentsCheckReferer',0,'1'),('commentsHTMLTagAllowed',0,''),('commentsListSize',0,'10'),('commentsMarkdown',0,'1'),('commentsMaxNestingLevels',0,'5'),('commentsOrder',0,'DESC'),('commentsPageBreak',0,'1'),('commentsPageDisplay',0,'last'),('commentsPageSize',0,'20'),('commentsPostInterval',0,'600'),('commentsPostIntervalEnable',0,'1'),('commentsPostTimeout',0,'2592000'),('commentsRequireMail',0,'1'),('commentsRequireModeration',0,'0'),('commentsRequireURL',0,'0'),('commentsShowCommentOnly',0,'0'),('commentsShowUrl',0,'1'),('commentsThreaded',0,'1'),('commentsUrlNofollow',0,'1'),('commentsWhitelist',0,'0'),('contentType',0,'text/html'),('defaultAllowComment',0,'1'),('defaultAllowComment',1,'1'),('defaultAllowFeed',0,'1'),('defaultAllowFeed',1,'1'),('defaultAllowPing',0,'1'),('defaultAllowPing',1,'1'),('defaultCategory',0,'1'),('description',0,'Love has its providence.'),('editorSize',0,'350'),('feedFullText',0,'0'),('frontArchive',0,'0'),('frontPage',0,'recent'),('generator',0,'Typecho 1.2.1'),('gzip',0,'0'),('installed',0,'1'),('keywords',0,'HTML,css,JavaScript,Vue,React,PHP,'),('lang',0,NULL),('markdown',0,'1'),('markdown',1,'1'),('pageSize',0,'5'),('panelTable',0,'a:0:{}'),('plugin:ColorHighlight',0,'a:3:{s:17:\"compatibilityMode\";s:1:\"1\";s:5:\"lines\";s:1:\"0\";s:5:\"style\";s:15:\"github-gist.css\";}'),('plugins',0,'a:2:{s:9:\"activated\";a:1:{s:14:\"ColorHighlight\";a:1:{s:7:\"handles\";a:5:{s:34:\"Widget_Abstract_Contents:contentEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:34:\"Widget_Abstract_Contents:excerptEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:34:\"Widget_Abstract_Comments:contentEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:21:\"Widget_Archive:header\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:6:\"header\";}}s:21:\"Widget_Archive:footer\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:6:\"footer\";}}}}}s:7:\"handles\";a:5:{s:34:\"Widget_Abstract_Contents:contentEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:34:\"Widget_Abstract_Contents:excerptEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:34:\"Widget_Abstract_Comments:contentEx\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:5:\"parse\";}}s:21:\"Widget_Archive:header\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:6:\"header\";}}s:21:\"Widget_Archive:footer\";a:1:{i:0;a:2:{i:0;s:21:\"ColorHighlight_Plugin\";i:1;s:6:\"footer\";}}}}'),('postDateFormat',0,'Y-m-d'),('postsListSize',0,'30'),('rewrite',0,'0'),('routingTable',0,'a:26:{i:0;a:25:{s:5:\"index\";a:6:{s:3:\"url\";s:1:\"/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:8:\"|^[/]?$|\";s:6:\"format\";s:1:\"/\";s:6:\"params\";a:0:{}}s:7:\"archive\";a:6:{s:3:\"url\";s:6:\"/blog/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:13:\"|^/blog[/]?$|\";s:6:\"format\";s:6:\"/blog/\";s:6:\"params\";a:0:{}}s:2:\"do\";a:6:{s:3:\"url\";s:22:\"/action/[action:alpha]\";s:6:\"widget\";s:14:\"\\Widget\\Action\";s:6:\"action\";s:6:\"action\";s:4:\"regx\";s:32:\"|^/action/([_0-9a-zA-Z-]+)[/]?$|\";s:6:\"format\";s:10:\"/action/%s\";s:6:\"params\";a:1:{i:0;s:6:\"action\";}}s:4:\"post\";a:6:{s:3:\"url\";s:23:\"/[category]/[slug].html\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:30:\"|^/([^/]+)/([^/]+)\\.html[/]?$|\";s:6:\"format\";s:11:\"/%s/%s.html\";s:6:\"params\";a:2:{i:0;s:8:\"category\";i:1;s:4:\"slug\";}}s:10:\"attachment\";a:6:{s:3:\"url\";s:26:\"/attachment/[cid:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:28:\"|^/attachment/([0-9]+)[/]?$|\";s:6:\"format\";s:15:\"/attachment/%s/\";s:6:\"params\";a:1:{i:0;s:3:\"cid\";}}s:8:\"category\";a:6:{s:3:\"url\";s:17:\"/category/[slug]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:25:\"|^/category/([^/]+)[/]?$|\";s:6:\"format\";s:13:\"/category/%s/\";s:6:\"params\";a:1:{i:0;s:4:\"slug\";}}s:3:\"tag\";a:6:{s:3:\"url\";s:12:\"/tag/[slug]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:20:\"|^/tag/([^/]+)[/]?$|\";s:6:\"format\";s:8:\"/tag/%s/\";s:6:\"params\";a:1:{i:0;s:4:\"slug\";}}s:6:\"author\";a:6:{s:3:\"url\";s:22:\"/author/[uid:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:24:\"|^/author/([0-9]+)[/]?$|\";s:6:\"format\";s:11:\"/author/%s/\";s:6:\"params\";a:1:{i:0;s:3:\"uid\";}}s:6:\"search\";a:6:{s:3:\"url\";s:19:\"/search/[keywords]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:23:\"|^/search/([^/]+)[/]?$|\";s:6:\"format\";s:11:\"/search/%s/\";s:6:\"params\";a:1:{i:0;s:8:\"keywords\";}}s:10:\"index_page\";a:6:{s:3:\"url\";s:21:\"/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:22:\"|^/page/([0-9]+)[/]?$|\";s:6:\"format\";s:9:\"/page/%s/\";s:6:\"params\";a:1:{i:0;s:4:\"page\";}}s:12:\"archive_page\";a:6:{s:3:\"url\";s:26:\"/blog/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:27:\"|^/blog/page/([0-9]+)[/]?$|\";s:6:\"format\";s:14:\"/blog/page/%s/\";s:6:\"params\";a:1:{i:0;s:4:\"page\";}}s:13:\"category_page\";a:6:{s:3:\"url\";s:32:\"/category/[slug]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:34:\"|^/category/([^/]+)/([0-9]+)[/]?$|\";s:6:\"format\";s:16:\"/category/%s/%s/\";s:6:\"params\";a:2:{i:0;s:4:\"slug\";i:1;s:4:\"page\";}}s:8:\"tag_page\";a:6:{s:3:\"url\";s:27:\"/tag/[slug]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:29:\"|^/tag/([^/]+)/([0-9]+)[/]?$|\";s:6:\"format\";s:11:\"/tag/%s/%s/\";s:6:\"params\";a:2:{i:0;s:4:\"slug\";i:1;s:4:\"page\";}}s:11:\"author_page\";a:6:{s:3:\"url\";s:37:\"/author/[uid:digital]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:33:\"|^/author/([0-9]+)/([0-9]+)[/]?$|\";s:6:\"format\";s:14:\"/author/%s/%s/\";s:6:\"params\";a:2:{i:0;s:3:\"uid\";i:1;s:4:\"page\";}}s:11:\"search_page\";a:6:{s:3:\"url\";s:34:\"/search/[keywords]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:32:\"|^/search/([^/]+)/([0-9]+)[/]?$|\";s:6:\"format\";s:14:\"/search/%s/%s/\";s:6:\"params\";a:2:{i:0;s:8:\"keywords\";i:1;s:4:\"page\";}}s:12:\"archive_year\";a:6:{s:3:\"url\";s:18:\"/[year:digital:4]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:19:\"|^/([0-9]{4})[/]?$|\";s:6:\"format\";s:4:\"/%s/\";s:6:\"params\";a:1:{i:0;s:4:\"year\";}}s:13:\"archive_month\";a:6:{s:3:\"url\";s:36:\"/[year:digital:4]/[month:digital:2]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:30:\"|^/([0-9]{4})/([0-9]{2})[/]?$|\";s:6:\"format\";s:7:\"/%s/%s/\";s:6:\"params\";a:2:{i:0;s:4:\"year\";i:1;s:5:\"month\";}}s:11:\"archive_day\";a:6:{s:3:\"url\";s:52:\"/[year:digital:4]/[month:digital:2]/[day:digital:2]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:41:\"|^/([0-9]{4})/([0-9]{2})/([0-9]{2})[/]?$|\";s:6:\"format\";s:10:\"/%s/%s/%s/\";s:6:\"params\";a:3:{i:0;s:4:\"year\";i:1;s:5:\"month\";i:2;s:3:\"day\";}}s:17:\"archive_year_page\";a:6:{s:3:\"url\";s:38:\"/[year:digital:4]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:33:\"|^/([0-9]{4})/page/([0-9]+)[/]?$|\";s:6:\"format\";s:12:\"/%s/page/%s/\";s:6:\"params\";a:2:{i:0;s:4:\"year\";i:1;s:4:\"page\";}}s:18:\"archive_month_page\";a:6:{s:3:\"url\";s:56:\"/[year:digital:4]/[month:digital:2]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:44:\"|^/([0-9]{4})/([0-9]{2})/page/([0-9]+)[/]?$|\";s:6:\"format\";s:15:\"/%s/%s/page/%s/\";s:6:\"params\";a:3:{i:0;s:4:\"year\";i:1;s:5:\"month\";i:2;s:4:\"page\";}}s:16:\"archive_day_page\";a:6:{s:3:\"url\";s:72:\"/[year:digital:4]/[month:digital:2]/[day:digital:2]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:55:\"|^/([0-9]{4})/([0-9]{2})/([0-9]{2})/page/([0-9]+)[/]?$|\";s:6:\"format\";s:18:\"/%s/%s/%s/page/%s/\";s:6:\"params\";a:4:{i:0;s:4:\"year\";i:1;s:5:\"month\";i:2;s:3:\"day\";i:3;s:4:\"page\";}}s:12:\"comment_page\";a:6:{s:3:\"url\";s:53:\"[permalink:string]/comment-page-[commentPage:digital]\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:36:\"|^(.+)/comment\\-page\\-([0-9]+)[/]?$|\";s:6:\"format\";s:18:\"%s/comment-page-%s\";s:6:\"params\";a:2:{i:0;s:9:\"permalink\";i:1;s:11:\"commentPage\";}}s:4:\"feed\";a:6:{s:3:\"url\";s:20:\"/feed[feed:string:0]\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:4:\"feed\";s:4:\"regx\";s:17:\"|^/feed(.*)[/]?$|\";s:6:\"format\";s:7:\"/feed%s\";s:6:\"params\";a:1:{i:0;s:4:\"feed\";}}s:8:\"feedback\";a:6:{s:3:\"url\";s:31:\"[permalink:string]/[type:alpha]\";s:6:\"widget\";s:16:\"\\Widget\\Feedback\";s:6:\"action\";s:6:\"action\";s:4:\"regx\";s:29:\"|^(.+)/([_0-9a-zA-Z-]+)[/]?$|\";s:6:\"format\";s:5:\"%s/%s\";s:6:\"params\";a:2:{i:0;s:9:\"permalink\";i:1;s:4:\"type\";}}s:4:\"page\";a:6:{s:3:\"url\";s:12:\"/[slug].html\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";s:4:\"regx\";s:22:\"|^/([^/]+)\\.html[/]?$|\";s:6:\"format\";s:8:\"/%s.html\";s:6:\"params\";a:1:{i:0;s:4:\"slug\";}}}s:5:\"index\";a:3:{s:3:\"url\";s:1:\"/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:7:\"archive\";a:3:{s:3:\"url\";s:6:\"/blog/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:2:\"do\";a:3:{s:3:\"url\";s:22:\"/action/[action:alpha]\";s:6:\"widget\";s:14:\"\\Widget\\Action\";s:6:\"action\";s:6:\"action\";}s:4:\"post\";a:3:{s:3:\"url\";s:23:\"/[category]/[slug].html\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:10:\"attachment\";a:3:{s:3:\"url\";s:26:\"/attachment/[cid:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:8:\"category\";a:3:{s:3:\"url\";s:17:\"/category/[slug]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:3:\"tag\";a:3:{s:3:\"url\";s:12:\"/tag/[slug]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:6:\"author\";a:3:{s:3:\"url\";s:22:\"/author/[uid:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:6:\"search\";a:3:{s:3:\"url\";s:19:\"/search/[keywords]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:10:\"index_page\";a:3:{s:3:\"url\";s:21:\"/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:12:\"archive_page\";a:3:{s:3:\"url\";s:26:\"/blog/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:13:\"category_page\";a:3:{s:3:\"url\";s:32:\"/category/[slug]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:8:\"tag_page\";a:3:{s:3:\"url\";s:27:\"/tag/[slug]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:11:\"author_page\";a:3:{s:3:\"url\";s:37:\"/author/[uid:digital]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:11:\"search_page\";a:3:{s:3:\"url\";s:34:\"/search/[keywords]/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:12:\"archive_year\";a:3:{s:3:\"url\";s:18:\"/[year:digital:4]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:13:\"archive_month\";a:3:{s:3:\"url\";s:36:\"/[year:digital:4]/[month:digital:2]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:11:\"archive_day\";a:3:{s:3:\"url\";s:52:\"/[year:digital:4]/[month:digital:2]/[day:digital:2]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:17:\"archive_year_page\";a:3:{s:3:\"url\";s:38:\"/[year:digital:4]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:18:\"archive_month_page\";a:3:{s:3:\"url\";s:56:\"/[year:digital:4]/[month:digital:2]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:16:\"archive_day_page\";a:3:{s:3:\"url\";s:72:\"/[year:digital:4]/[month:digital:2]/[day:digital:2]/page/[page:digital]/\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:12:\"comment_page\";a:3:{s:3:\"url\";s:53:\"[permalink:string]/comment-page-[commentPage:digital]\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}s:4:\"feed\";a:3:{s:3:\"url\";s:20:\"/feed[feed:string:0]\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:4:\"feed\";}s:8:\"feedback\";a:3:{s:3:\"url\";s:31:\"[permalink:string]/[type:alpha]\";s:6:\"widget\";s:16:\"\\Widget\\Feedback\";s:6:\"action\";s:6:\"action\";}s:4:\"page\";a:3:{s:3:\"url\";s:12:\"/[slug].html\";s:6:\"widget\";s:15:\"\\Widget\\Archive\";s:6:\"action\";s:6:\"render\";}}'),('secret',0,'hCXdrhvAbCuREq#^H#2iVfnaBIZfAzzd'),('siteUrl',0,'https://blog.adlerian.xyz'),('theme',0,'default'),('theme:default',0,'a:2:{s:7:\"logoUrl\";N;s:12:\"sidebarBlock\";a:5:{i:0;s:15:\"ShowRecentPosts\";i:1;s:18:\"ShowRecentComments\";i:2;s:12:\"ShowCategory\";i:3;s:11:\"ShowArchive\";i:4;s:9:\"ShowOther\";}}'),('timezone',0,'28800'),('title',0,'Moose cat 博客'),('xmlrpcMarkdown',0,'0'),('xmlrpcMarkdown',1,'1');
/*!40000 ALTER TABLE `typecho_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_relationships`
--

DROP TABLE IF EXISTS `typecho_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_relationships` (
  `cid` int(10) unsigned NOT NULL,
  `mid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`cid`,`mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_relationships`
--

LOCK TABLES `typecho_relationships` WRITE;
/*!40000 ALTER TABLE `typecho_relationships` DISABLE KEYS */;
INSERT INTO `typecho_relationships` VALUES (4,2),(4,3),(4,4),(4,5),(4,6),(4,7),(5,8),(5,9),(5,10),(5,11),(5,12);
/*!40000 ALTER TABLE `typecho_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `typecho_users`
--

DROP TABLE IF EXISTS `typecho_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typecho_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `password` varchar(64) DEFAULT NULL,
  `mail` varchar(150) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `screenName` varchar(32) DEFAULT NULL,
  `created` int(10) unsigned DEFAULT '0',
  `activated` int(10) unsigned DEFAULT '0',
  `logged` int(10) unsigned DEFAULT '0',
  `group` varchar(16) DEFAULT 'visitor',
  `authCode` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `typecho_users`
--

LOCK TABLES `typecho_users` WRITE;
/*!40000 ALTER TABLE `typecho_users` DISABLE KEYS */;
INSERT INTO `typecho_users` VALUES (1,'adler','$P$Bk52My.ip0uMh6EbhD2nhwMO8qpFyH.','daiyunjie@adlerian.xyz','https://blog.adlerian.xyz/','Adlerian',1691718206,1692094296,1692009312,'administrator','b9023f81eb18a3ff18f46b5bafe5349c');
/*!40000 ALTER TABLE `typecho_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'daiyunjie_cn'
--

--
-- Dumping routines for database 'daiyunjie_cn'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-19  2:30:01
